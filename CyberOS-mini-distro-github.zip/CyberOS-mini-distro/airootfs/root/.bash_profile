if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
  /usr/local/bin/cyber-install
fi
