#!/bin/bash
# Прогоняет cyber-install через несколько сценариев с подставными
# командами вместо реальных (parted, mkfs, cryptsetup, arch-chroot...)
# и проверяет ключевые свойства безопасности — в первую очередь то,
# что режим "рядом с существующей ОС" никогда не форматирует и не
# трогает уже существующие разделы.
#
# Это НЕ проверяет реальную загрузку/разметку на живом железе — только
# то, что сам bash-скрипт делает именно те вызовы, которые должен, в
# правильном порядке и с правильными аргументами. Реальный boot-тест
# в VM всё равно необходим перед использованием на настоящем диске.
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKDIR=$(mktemp -d)
export FAKE_FIXTURES="$ROOT/tests/fixtures"
FAIL=0
PASS=0

# --- Готовим тестируемую копию cyber-install: только то, что нельзя
# --- иметь по-настоящему в CI (реальный /etc/issue, реальный /dev/sda,
# --- реальная EFI-прошивка, реальную перезагрузку) — заменяем на
# --- безобидные эквиваленты. Сама логика скрипта не меняется ни на строку.
SUT="$WORKDIR/cyber-install"
cp "$ROOT/airootfs/usr/local/bin/cyber-install" "$SUT"
sed -i '/^cat \/etc\/issue$/d' "$SUT"
sed -i 's#^reboot$#echo "(reboot)"#' "$SUT"
sed -i 's#if \[\[ ! -d /sys/firmware/efi/efivars \]\]; then#if false; then#' "$SUT"
sed -i 's#\[\[ -b "\$DISK" \]\] || { echo "Устройство \$DISK не найдено."; exit 1; }#true#' "$SUT"
cp "$ROOT/packages.x86_64" "$WORKDIR/packages.x86_64"
sed -i "s#/root/packages.x86_64#$WORKDIR/packages.x86_64#" "$SUT"

run_scenario() {
  local name="$1"; shift
  export FAKE_LOG="$WORKDIR/$name.log"
  export FAKE_STATE="$WORKDIR/$name.state"
  mkdir -p "$FAKE_STATE"
  : > "$FAKE_LOG"
  # cyber-install всегда работает с настоящим /mnt (mount/umount сами
  # подставные, но mkdir и genfstab — нет), поэтому готовим реальный /mnt.
  rm -rf /mnt/etc /mnt/boot /mnt/windows /mnt/mnt 2>/dev/null
  mkdir -p /mnt/etc /mnt/boot/loader/entries
  ( PATH="$ROOT/tests/fakebin:$PATH" bash "$SUT" ) < "$1" &> "$WORKDIR/$name.out"
  rm -rf /mnt/etc /mnt/boot /mnt/windows /mnt/mnt 2>/dev/null
}

assert_contains() {
  local file="$1" pattern="$2" desc="$3"
  if grep -qE "$pattern" "$file"; then
    echo "  OK   $desc"
    PASS=$((PASS+1))
  else
    echo "  FAIL $desc (не нашёл: $pattern)"
    FAIL=$((FAIL+1))
  fi
}

assert_not_contains() {
  local file="$1" pattern="$2" desc="$3"
  if grep -qE "$pattern" "$file"; then
    echo "  FAIL $desc (нашёл запрещённое: $pattern)"
    FAIL=$((FAIL+1))
  else
    echo "  OK   $desc"
    PASS=$((PASS+1))
  fi
}

echo "== Сценарий: весь диск, без шифрования =="
printf '/dev/sda\n1\nERASE\nn\nUTC\ntester\ncyberos\nhunter22\nhunter22\n\n' > "$WORKDIR/answers"
run_scenario wipe-basic "$WORKDIR/answers"
assert_contains    "$WORKDIR/wipe-basic.log" '^wipefs -af /dev/sda$'         "стирает весь диск"
assert_contains    "$WORKDIR/wipe-basic.log" '^mkfs\.fat -F32 /dev/sda1$'   "форматирует новый ESP"
assert_contains    "$WORKDIR/wipe-basic.log" '^mkfs\.btrfs -f /dev/sda2$'   "форматирует btrfs на sda2"
assert_not_contains "$WORKDIR/wipe-basic.log" '^cryptsetup '                 "не шифрует без запроса"
assert_contains     "$WORKDIR/wipe-basic.log" 'cp -a /etc/skel/\. /mnt/etc/skel/'         "переносит кастомный /etc/skel на целевую систему"
assert_contains     "$WORKDIR/wipe-basic.log" 'cp /usr/share/xsessions/i3\.desktop'       "переносит запись сессии i3 для lightdm"
assert_contains     "$WORKDIR/wipe-basic.log" 'base64 -d > /usr/local/bin/cyberos-doctor' "ставит cyberos-doctor на целевую систему"
assert_contains     "$WORKDIR/wipe-basic.log" 'enable cyberos-update-check.timer cyberos-paccache.timer' "включает еженедельное обновление метаданных и очистку кэша"

echo "== Сценарий: весь диск, с шифрованием =="
printf '/dev/sda\n1\nERASE\ny\ncryptpass\ncryptpass\nUTC\ntester\ncyberos\nhunter22\nhunter22\n\n' > "$WORKDIR/answers"
run_scenario wipe-luks "$WORKDIR/answers"
assert_contains "$WORKDIR/wipe-luks.log" 'cryptsetup luksFormat --type luks2 -q /dev/sda2 -' "шифрует правильный раздел"
assert_contains "$WORKDIR/wipe-luks.log" 'sd-encrypt'                                        "переключает hooks на sd-encrypt"

echo "== Сценарий: рядом с существующей ОС (Windows), без шифрования =="
printf '/dev/sda\n2\nALONGSIDE\nn\nUTC\ntester\ncyberos\nhunter22\nhunter22\n\n' > "$WORKDIR/answers"
run_scenario alongside-basic "$WORKDIR/answers"
assert_not_contains "$WORKDIR/alongside-basic.log" '^wipefs'                     "НИКОГДА не вызывает wipefs рядом с ОС"
assert_not_contains "$WORKDIR/alongside-basic.log" '^mkfs\.fat'                  "НИКОГДА не форматирует существующий ESP"
assert_not_contains "$WORKDIR/alongside-basic.log" 'mklabel'                     "не пересоздаёт таблицу разделов"
assert_contains     "$WORKDIR/alongside-basic.log" 'mkpart primary btrfs 450000MiB 500000MiB' "новый раздел точно в границах свободного места"
assert_contains     "$WORKDIR/alongside-basic.log" '^mkfs\.btrfs -f /dev/sda4$'  "форматирует ТОЛЬКО новый раздел (sda4)"
assert_contains     "$WORKDIR/alongside-basic.out" '/mnt/windows'                "предлагает доступ к разделу Windows"
assert_contains     "$WORKDIR/alongside-basic.log" 'cp -a /etc/skel/\. /mnt/etc/skel/'     "переносит кастомный /etc/skel и в режиме 'рядом с ОС'"

echo "== Сценарий: рядом с существующей ОС + шифрование =="
printf '/dev/sda\n2\nALONGSIDE\ny\ncryptpass\ncryptpass\nUTC\ntester\ncyberos\nhunter22\nhunter22\n\n' > "$WORKDIR/answers"
run_scenario alongside-luks "$WORKDIR/answers"
assert_not_contains "$WORKDIR/alongside-luks.log" '^wipefs'                          "рядом+шифрование: не трогает существующие разделы"
assert_contains     "$WORKDIR/alongside-luks.log" 'cryptsetup luksFormat --type luks2 -q /dev/sda4 -' "шифрует именно новый раздел, не ESP"

echo "== Сценарий: NVMe-диск, весь диск (проверка именования p1/p2, не 1/2) =="
printf '/dev/nvme0n1\n1\nERASE\nn\nUTC\ntester\ncyberos\nhunter22\nhunter22\n\n' > "$WORKDIR/answers"
run_scenario wipe-nvme "$WORKDIR/answers"
assert_contains "$WORKDIR/wipe-nvme.log" '^mkfs\.fat -F32 /dev/nvme0n1p1$' "ESP на NVMe с правильным 'p' в имени"
assert_contains "$WORKDIR/wipe-nvme.log" '^mkfs\.btrfs -f /dev/nvme0n1p2$' "btrfs на NVMe с правильным 'p' в имени"

echo "== Сценарий: mmcblk-диск (SD/eMMC), весь диск =="
printf '/dev/mmcblk0\n1\nERASE\nn\nUTC\ntester\ncyberos\nhunter22\nhunter22\n\n' > "$WORKDIR/answers"
run_scenario wipe-mmcblk "$WORKDIR/answers"
assert_contains "$WORKDIR/wipe-mmcblk.log" '^mkfs\.fat -F32 /dev/mmcblk0p1$'  "ESP на mmcblk с правильным 'p' в имени"
assert_contains "$WORKDIR/wipe-mmcblk.log" '^mkfs\.btrfs -f /dev/mmcblk0p2$' "btrfs на mmcblk с правильным 'p' в имени"

echo "== Сценарий: NVMe-диск, рядом с существующей ОС =="
printf '/dev/nvme0n1\n2\nALONGSIDE\nn\nUTC\ntester\ncyberos\nhunter22\nhunter22\n\n' > "$WORKDIR/answers"
run_scenario alongside-nvme "$WORKDIR/answers"
assert_not_contains "$WORKDIR/alongside-nvme.log" '^wipefs'                           "NVMe рядом с ОС: не трогает существующие разделы"
assert_contains     "$WORKDIR/alongside-nvme.log" 'mkpart primary btrfs 450000MiB 500000MiB' "новый раздел на NVMe в границах свободного места"
assert_contains     "$WORKDIR/alongside-nvme.log" '^mkfs\.btrfs -f /dev/nvme0n1p4$'   "новый раздел на NVMe правильно назван (p4, не просто 4)"

echo
echo "Пройдено: $PASS, провалено: $FAIL"
rm -rf "$WORKDIR"
[[ "$FAIL" -eq 0 ]]
